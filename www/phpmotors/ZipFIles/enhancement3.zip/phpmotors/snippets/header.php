<p><a href='/phpmotors/accounts/index.php?action=signin'>My Account</a></p>
<img src="/phpmotors/images/site/logo.png" alt="DeLorean_Logo">
